<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@taglib uri="http://java.sun.com/jstl/fmt_rt" prefix="fmt" %>
<%@taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>Hello</h1>
<a href="Lab3bai1">bài 1</a>  ||
<a href="Lab3bai2">bài 2</a>  ||
<a href="Lab3bai3">bài 3</a>  ||
<a href="Lab3bai4">bài 4</a>  ||
<hr/>

<li>Title: ${fn:toUpperCase(item.title)}</li>
<li>Content:
<c:choose>
    <c:when test="${fn:length(item.content) > 100}">
        ${fn:substring(item.content, 0, 100)}...
    </c:when>
    <c:otherwise>${item.content}</c:otherwise>
</c:choose>
</li>

</body>
</html>
