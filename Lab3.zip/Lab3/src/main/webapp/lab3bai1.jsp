<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href="lab3bai1">Bài 1</a>||
<a href="lab3bai2">Bài 2</a>||
<a href="lab3bai3">Bài 3</a>||
<a href="lab3bai4">Bài 4</a>||
<hr/>
<select name="country"> 
 <c:forEach var="ct" items="${countries}"> 
  <option value="${ct.id}">${ct.name}</option> 
 </c:forEach>
 </select> 
</body>
</html>