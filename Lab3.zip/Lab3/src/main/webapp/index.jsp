<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href="lab3bai1">Bài 1</a>||
<a href="lab3bai2">Bài 2</a>||
<a href="lab3bai3">Bài 3</a>||
<a href="lab3bai4">Bài 4</a>||
<hr/>
</body>
</html>